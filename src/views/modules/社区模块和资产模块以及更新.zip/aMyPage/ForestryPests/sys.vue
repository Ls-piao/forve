<template>
    <div class='container'>

    </div>
</template>

<script>
export default {
     name:'',
    components: {

    },
    props: {

    },
    data() {
        return {

        };
    },
    computed: {

    },
    watch: {

    },
    created() {

    },
    mounted() {

    },
    methods: {

    },
};
</script>

<style scoped lang="scss">

.container{
height: 100%;
width: 100%
}
</style>
