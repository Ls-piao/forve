<template>
  <div class="container"> 
      <img src="./static/test.png" class="img" alt="">
  </div>
</template>

<script>
export default {
  name: "",
  components: {},
  props: {},
  data() {
    return {};
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {},
};
</script>

<style scoped lang="scss">
.container{
    width: 100%;
    height: 100%;
    img{
        width:100%;height: 100%;
        object-fit: cover;
    }
}
</style>
