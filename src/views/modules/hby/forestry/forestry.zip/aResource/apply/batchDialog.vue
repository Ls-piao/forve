<template>
  <el-dialog
    v-dialogDrag
    :visible.sync="visible"
    :close-on-click-modal="false"
    @closed="cancelForm"
    class="dia"
    title="审核"
  >
    <div class="dia-content">
      <el-form label-position="left" label-width="120px" size="mini" >
        <!-- <el-form-item label="待审核申请表">
          <div v-for="v in data" :key="v.ID">
            {{v.ID}}
          </div>
        </el-form-item> -->
        <el-form-item label="审核结果">
          <el-radio v-model="radio" :label="2">通过</el-radio>
          <el-radio v-model="radio" :label="0">不通过</el-radio>
        </el-form-item>
        <el-form-item label="审核意见">
          <el-input
            type="textarea"
            placeholder="请输入"
            v-model="approveOpinion"
          ></el-input>
        </el-form-item>
      </el-form>
      <div class="footer">
        <el-button
          @click="cancelForm"
          >取消</el-button
        >
        <el-button type="primary" @click="batchCheckCommit">确认审核</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script>
export default {
  data () {
    return {
      visible: false,
      data: '',
      radio: '',
      approveOpinion: ''
    }
  },
  computed: {},
  mounted () {},
  methods: {
    init (v) {
      this.data = v
      this.visible = true
    },
    cancelForm () {
      this.visible = false
      this.approveOpinion = ''
      this.radio = ''
    },
    batchCheckCommit () {
      if (this.radio === '') {
        this.$message.error('请先选择审批结果')
        return
      }
      let to = this.$loading('审批中')
      try {
        for (let x of this.data) {
          x.status = this.radio
          this.$http({
            url: '/hby/lqgl/lqsp/save',
            method: 'post',
            data: x
          }).then(({ data }) => {
            if (data.code === 200) {
              this.loading = false
              this.visible = false
            }
          })
        }
        this.$message.success('操作成功')
      } catch (error) {
        this.$message.success('审批失败')
      } finally {
        to.close()
        this.cancelForm()
        this.$parent.$refs.table.initData() // 刷新表格
      }
    }
  }
}
</script>
<style lang="less">
// .dia {
//   .el-dialog__header {
//     color: #fff;
//     background: linear-gradient(
//       to right,
//       rgb(74, 108, 219),
//       #3f8ef7,
//       #2d9dc9,
//       #3f8ef7
//     ) !important;
//     span {
//       color: #fff;
//     }
//     i {
//       color: #fff;
//     }
//   }
//   .el-dialog__body {
//     background-color: #fff !important;
//   }
// }
// .dia-content {
//   .el-form {
//     .el-form-item {
//       .el-form-item__label {
//         line-height: 32px !important;
//       }
//       .el-form-item__content {
//         .el-textarea {
//           textarea {
//             min-height: 200px !important;
//           }
//         }
//       }
//     }
//   }
// }
</style>
<style lang="scss" scoped>
.footer {
  justify-content: flex-end;
  text-align: right;
}

</style>
