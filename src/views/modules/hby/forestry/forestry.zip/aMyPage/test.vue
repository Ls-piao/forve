<template>
  <el-row>
    <el-col> test </el-col>
  </el-row>
</template>
<script>
export default {
  data () {
    return {}
  },
  methods: {},
  watch: {},
  computed: {}
}
</script>

<style lang='less' scoped>
</style>